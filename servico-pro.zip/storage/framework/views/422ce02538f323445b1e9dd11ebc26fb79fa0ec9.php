<div>
    <div class="row">
        <div class="col-sm-12">
            <label>Nome:</label>
            <?php echo e($cliente->nome); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-3">
            <label>Endereço:</label>
            <?php echo e($cliente->endereco); ?>

        </div>
        <div class="col-sm-3">
            <label>Número:</label>
            <?php echo e($cliente->numero); ?>

        </div>
        <div class="col-sm-3">
            <label>Cidade:</label>
            <?php echo e($cliente->cidade); ?>

        </div>
        <div class="col-sm-3">
            <label>Bairro:</label>
            <?php echo e($cliente->bairro); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <label>Referência:</label>
            <?php echo e($cliente->referencia); ?>

        </div>
        <div class="col-sm-4">
            <label>Telefone 1:</label>
            <?php echo e($cliente->telefone); ?>

        </div>
        <div class="col-sm-4">
            <label>Telefone 2:</label>
            <?php echo e($cliente->telefone2); ?>

        </div>
    </div>
</div>