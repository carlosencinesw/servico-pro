<?php $__env->startSection('content'); ?>
<div class="row">
    <h1><i class="fa fa-tasks"></i> <span>O.S n° <?php echo e($servico->cod_os); ?> - <?php echo e($servico->cliente->nome); ?></span></h1>
</div>
<div class="row">
    <a class="btn btn-warning" href="javascript:$('#servico-edit').modal('show')" data-toggle="modal" data-target=".servico-<?php echo e($servico->id); ?>"><i class="fa fa-edit"></i> <span>Editar</span></a>
    <a class="btn btn-primary" href="<?php echo e(route('app.modulos.servicos.index')); ?>"><i class="fa fa-chevron-circle-left"></i> <span>Voltar</span></a>
    <a class="btn btn-default" href="<?php echo e(url('app/dashboard')); ?>"><i class="fa fa-home"></i> <span>Voltar para a dashboard</span></a>
</div>
<div class="row">
    <div class="col-sm-12 h3">
        <label for="endereco">Endereço de entrega:</label>
        <?php echo e($servico->cliente->endereco); ?>

    </div>
</div>
<div class="row">
    <div class="col-sm-6">
        <label for="lista">Serviços solicitados:</label>
        <ul class="listagem-produtos list-group">
            <?php for($i = 0; $i < count($produtos["produtos"]["listagem"]); $i++): ?>
            <li class="list-group-item"><?php echo e($produtos["produtos"]["listagem"][$i]); ?></li>
            <?php endfor; ?>
        </ul>            
    </div>
</div>
<div class="row">
    <div class="col-sm-3">
        <label for="">Dia da entrrega:</label>
        <p class="alert"><?php echo e($servico->dia_entrega); ?></p>

    </div>
    <div class="col-sm-3">
        <label for="">Turno de entrega:</label>
        <p class="alert"><?php echo e($servico->turno_entrega); ?></p>

    </div>
    <div class="col-sm-3">
        <label for="">Status da entrega:</label>
        <?php if($servico->status_entrega == "realizada"): ?>
        <p class="alert status_ok"><?php echo e(ucwords($servico->status_entrega)); ?></p>
        <?php elseif($servico->status_entrega == "não-realizada"): ?>
        <p class="alert status_not_ok"><?php echo e(ucwords($servico->status_entrega)); ?></p>
        <?php endif; ?>
    </div>
    <div class="col-sm-3">
        <label for="">Pagamento:</label>
        <?php if($servico->status_pagamento == "efetuado"): ?>
        <p class="alert status_ok"><?php echo e(ucwords($servico->status_pagamento)); ?></p>
        <?php elseif($servico->status_pagamento == "aguardando"): ?>
        <p class="alert status_pending"><?php echo e(ucwords($servico->status_pagamento)); ?></p>
        <?php else: ?>
        <p class="alert status_not_ok"><?php echo e(ucwords($servico->status_pagamento)); ?></p>
        <?php endif; ?>
    </div>

    <?php /*Editar O.S*/ ?>
    <div class="modal modal-warning fade servico-<?php echo e($servico->id); ?>" tabindex="-1" id="servico-edit"
       role="dialog">
       <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title"><i class="fa fa-edit"></i> <span>Editar Serviço</span>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span></button>
                    </h3>
                </div>
                <div class="modal-body">                    
                    <div class="alert alert-danger messageError"></div>
                    <div class="alert alert-success message"></div>
                    <p class="row">
                        <?php echo $__env->make('servicos.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </p>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>