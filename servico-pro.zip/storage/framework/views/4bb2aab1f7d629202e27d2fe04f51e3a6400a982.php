<?php $__env->startSection('content'); ?>
    <div class="row">
        <h1><i class="fa fa-comment-o"></i> <span>Feedback</span></h1>
    </div>
    <div class="row">
        <div class="col-sm-8">
            <form action="<?php echo e(route('send.feedback')); ?>" method="post" class="form-horizontal">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label>Nome:</label>
                    <input type="text" name="user" class="form-control disabled">
                </div>
                <div class="form-group">
                    <label>Mensagem:</label>
                    <textarea name="msg" class="form-control" cols="30" rows="10"></textarea>
                </div>
                <div class="form-group">
                    <button class="btn btn-success btn-block" type="submit"><i class="fa fa-check"></i> <span>Enviar Feedback</span></button>
                </div>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>