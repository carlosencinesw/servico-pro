<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <h1><i class="fa fa-user"></i> <span>Editar Usuário</span></h1>
        </div>
    </div>
    <div class="container pull-left">
        <div class="row">
            <form class="form-horizontal" action="<?php echo e(route('usuario.update', $user->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="PUT">
                <div class="form-group">
                    <div class="col-sm-8">
                        <label>Nome:</label>
                        <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>">
                    </div>
                    <div class="col-sm-4">
                        <label>E-mail:</label>
                        <input class="form-control" type="text" name="email" value="<?php echo e($user->email); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label>Alterar Senha:</label>
                        <input class="form-control" type="password" name="password">
                    </div>
                    <div class="col-sm-6">
                        <label>Confirmar senha:</label>
                        <input class="form-control" type="password" name="confirm_password">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <button class="btn btn-success btn-block" type="submit"><i class="fa fa-check"></i> <span>Atualizar perfil</span></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>