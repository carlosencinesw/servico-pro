<?php /*<?php foreach($lists as $lista): ?>
    <li class="list-group-item"><?php echo e($lista['produtos'][0][0]); ?></li>
<?php endforeach; ?>*/ ?>
<?php /*<?php echo e(dump($lists["produtos"]["listagem"][0])); ?>*/ ?>
<?php for($i = 0; $i < count($lists['produtos']["listagem"]); $i++): ?>
    <li class="list-group-item"><?php echo e($lists["produtos"]["listagem"][$i]); ?></li>
<?php endfor; ?>
