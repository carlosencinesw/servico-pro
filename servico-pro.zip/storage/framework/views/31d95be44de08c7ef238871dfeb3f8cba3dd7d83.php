<?php $__env->startSection('content'); ?>
    <div class="row"><h1><i class="fa fa-users"></i> <span>Clientes</span></h1></div>
    <div class="row">
        <a class="btn btn-success" href="javascript:$('#create').modal('show')"
           data-toggle="modal" data-target=".create-cliente"><i class="fa fa-plus"></i> Adicionar</a>
    </div>
    <div class="row">
        <?php if(session('msg')): ?>
            <div class="alert alert-success delete-success"><?php echo e(session('msg')); ?></div>
        <?php endif; ?>
    </div>
    <div class="row">
        <table class="table table-responsive">
            <thead>
            <th>Nome</th>
            <th>Endereço</th>
            <th>Telefone</th>
            <th>Ações</th>
            </thead>
            <tbody>
            <?php foreach($clientes as $cliente): ?>
                <tr>
                    <td><?php echo e($cliente->nome); ?></td>
                    <td><?php echo e($cliente->endereco); ?></td>
                    <td><?php echo e($cliente->telefone); ?></td>
                    <td>
                        <a class="btn btn-info" href="javascript:$('#info-cliente').modal('show')"
                           data-toggle="modal" data-target=".info-<?php echo e($cliente->id); ?>"><i class="fa fa-info"></i> Ver detalhes</a>

                        <a class="btn btn-warning" href="javascript:$('#cliente-edit').modal('show')"
                           data-toggle="modal" data-target=".cliente-<?php echo e($cliente->id); ?>"><i class="fa fa-edit"></i>
                            Editar</a>

                        <a class="btn btn-danger" href="javascript:$('#deletar-cliente').modal('show')"
                           data-toggle="modal" data-target=".delete-<?php echo e($cliente->id); ?>"><i class="fa fa-trash"></i>
                            Excluir</a>

                        <?php /*Modal para edição de clientes*/ ?>
                        <div class="modal modal-warning fade cliente-<?php echo e($cliente->id); ?>" tabindex="-1" id="cliente-edit"
                             role="dialog">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h3 class="modal-title"><i class="fa fa-edit"></i> <span>Editar Cliente</span>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">x</span></button>
                                        </h3>
                                    </div>
                                    <div class="modal-body">
                                        <div class="alert alert-success message"></div>
                                        <p class="row">
                                            <?php echo $__env->make('partials.clientes.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </p>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <?php /*Modal para deletar clientes*/ ?>
                        <div class="modal modal-danger fade delete-<?php echo e($cliente->id); ?>" id="delete-cliente">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h3 class="modal-title"><i class="fa fa-trash"></i> <span>Excluir</span>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">x</span></button>
                                        </h3>

                                    </div>
                                    <div class="modal-body">
                                        <p>Tem certeza que quer excluir o cliente <b><?php echo e($cliente->nome); ?></b>?</p>
                                    </div>
                                    <div class="modal-footer">
                                        <form action="<?php echo e(route('app.modulos.clientes.destroy', $cliente->id)); ?>"
                                              method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="_method" value="DELETE">
                                            <button type="submit" class="btn btn-danger"><i class="fa fa-check"></i>
                                                <span>Sim</span></button>
                                            <a href="" data-dismiss="modal" class="btn btn-default"><i
                                                        class="fa fa-times"></i> <span>Não</span></a>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php /*Modal para exibir informações sobre os clientes*/ ?>
                        <div class="modal modal-info fade info-<?php echo e($cliente->id); ?>" id="info-cliente">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h3 class="modal-title"><i class="fa fa-info"></i> <span>Detalhes</span>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">x</span></button>
                                        </h3>
                                    </div>
                                    <div class="modal-body">
                                        <?php echo $__env->make('partials.clientes.show', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true"><i class="fa fa-sign-out"></i>Sair</span></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>

            <?php /*Modal para abrir formulário de criação de novo registro*/ ?>
            <div class="modal modal-success fade create-cliente" id="create">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title"><i class="fa fa-user"></i> <span>Adicionar cliente</span>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">x</span></button>
                            </h3>
                        </div>
                        <div class="modal-body">
                            <div class="alert alert-success message"></div>
                            <div class="alert alert-danger messageError"></div>
                            <?php echo $__env->make('clientes.add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>

        </table>
        <?php echo e($clientes->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>