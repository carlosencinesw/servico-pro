<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1><i class="fa fa-edit"></i> <span>Editar Cliente</span></h1>
        <form action="<?php echo e(route('clientes.main.update', $cliente->id)); ?>" class="form-horizontal" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="_method" value="PUT">
            <div class="form-group">
                <div class="form-group">
                    <div class="col-sm-12">
                        <label for="">Nome</label>
                        <input type="text" name="nome" value="<?php echo e($cliente->nome); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-3">
                        <label>Endereço</label>
                        <input type="text" name="endereco" value="<?php echo e($cliente->endereco); ?>" class="form-control">
                    </div>
                    <div class="col-sm-3">
                        <label>Numero</label>
                        <input type="text" name="numero" value="<?php echo e($cliente->numero); ?>" class="form-control">
                    </div>
                    <div class="col-sm-3">
                        <label>Cidade</label>
                        <input type="text" name="cidade" value="<?php echo e($cliente->cidade); ?>" class="form-control">
                    </div>
                    <div class="col-sm-3">
                        <label>Bairro</label>
                        <input type="text" name="bairro" value="<?php echo e($cliente->bairrro); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-4">
                        <label>Referência</label>
                        <input type="text" name="referencia" value="<?php echo e($cliente->referencia); ?>" class="form-control">
                    </div>
                    <div class="col-sm-4">
                        <label>Telefone 1</label>
                        <input type="text" name="telefone" value="<?php echo e($cliente->telefone); ?>" class="form-control">
                    </div>
                    <div class="col-sm-4">
                        <label>Telefone 2</label>
                        <input type="text" name="telefone2" value="<?php echo e($cliente->telefone2); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <button type="submit" class="btn btn-success"><i class="fa fa-check-circle"></i> Cadastrar
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>