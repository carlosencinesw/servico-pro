<?php $__env->startSection('content'); ?>
<div class="row"><h1><i class="fa fa-tasks"></i> Serviços</h1></div>
<div class="row">
    <?php if(session('msg')): ?>
    <div class="alert alert-success delete-success"><?php echo e(session('msg')); ?></div>
    <?php endif; ?>
</div>
<div class="row">
    <a class="btn btn-success" href="javascript:$('#create')" data-toggle="modal" data-target=".create-servico"><i
        class="fa fa-clock-o"></i> Agendar Serviço</a>
        <input class="search form-control" type="text" placeholder="Buscar Serviços">
    </div>
    <div class="row">
        <table class="table table-responsive table-hover">
            <thead>                
                <th>Código</th>
                <th>Cliente</th>
                <th>Entraga</th>
                <th>Status da entrega</th>
                <th>Status do pagamento</th>
                <th>Ações</th>
            </thead>
            <tbody>
                <?php foreach($servicos as $servico): ?>
                <tr>                            
                    <td><a class="btn btn-link show-servico" href="<?php echo e(route('app.modulos.servicos.show', $servico->id)); ?>"><?php echo e($servico->cod_os); ?></a></td>
                    <td><?php echo e($servico->cliente->nome); ?></td>
                    <td><?php echo e($servico->dia_entrega); ?> - <?php echo e($servico->turno_entrega); ?></td>
                    <?php if($servico->status_entrega == 'realizada'): ?>
                    <td class="alert">                        
                        <i class="fa fa-check fa-2x text-success"></i>                               
                    </td>
                    <?php elseif($servico->status_pagamento == 'aguardando'): ?>
                    <td class="alert">
                    <i class="fa fa-exclamation-triangle fa-2x text-warning"></i>
                    </td>
                    <?php else: ?>
                    <td class="alert">
                    <i class="fa fa-ban fa-2x text-danger"></i>
                    </td>
                    <?php endif; ?>
                    <?php if($servico->status_pagamento == 'efetuado'): ?>
                    <td>
                        <i class="fa fa-check fa-2x text-success"></i>
                    </td>
                    <?php elseif($servico->status_pagamento == 'aguardando'): ?>
                    <td class="alert">
                        <i class="fa fa-exclamation-triangle fa-2x text-warning"></i>
                    </td>
                    <?php else: ?>
                    <td class="alert">
                        <i class="fa fa-ban fa-2x text-danger"></i>
                    </td>
                    <?php endif; ?>                    

                    <td>
                        <a class="btn btn-info" href="javascript:$('#update_status').modal('show')" data-toggle="modal" data-target=".servico-status-<?php echo e($servico->id); ?>"><i class="fa fa-refresh"></i> <span>Atualizar Status</span></a>                        
                        <a class="btn btn-danger" href="javascript:$('#delete-servico').modal('show')"><i class="fa fa-trash"></i> <span>Excluir</span></a>

                        <?php /*Modal para atualizar os status do serviço*/ ?>
                        <div class="modal modal-warning fade servico-status-<?php echo e($servico->id); ?>" id="update_status">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h3 class="modal-title"><i class="fa fa-tasks"></i> <span>Atualizar Status do Serviço</span>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">x</span></button>
                                            </h3>
                                        </div>
                                        <div class="modal-body">
                                            <div class="alert alert-success message"></div>
                                            <div class="alert alert-danger messageError"></div>
                                            <?php echo $__env->make('servicos.status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>                            

                            <?php /*Modal para deletar serviços*/ ?>
                            <div class="modal modal-danger fade delete-<?php echo e($servico->id); ?>" id="delete-servico">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h3 class="modal-title"><i class="fa fa-trash"></i> <span>Excluir</span>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">x</span></button>
                                                </h3>

                                            </div>
                                            <div class="modal-body">
                                                <p>Excluir O.S n° <b><?php echo e($servico->cod_os); ?></b>?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <form action="<?php echo e(route('app.modulos.servicos.destroy', $servico->id)); ?>"
                                                  method="post">
                                                  <?php echo e(csrf_field()); ?>

                                                  <input type="hidden" name="_method" value="DELETE">
                                                  <button type="submit" class="btn btn-danger"><i class="fa fa-check"></i>
                                                    <span>Sim</span></button>
                                                    <a href="" data-dismiss="modal" class="btn btn-default"><i
                                                        class="fa fa-times"></i> <span>Não</span></a>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php echo e($servicos->links()); ?>

                </div>

                <?php /*Modal para exibir formulario de cadastro de nova O.S*/ ?>
                <div class="modal modal-success fade create-servico" id="create">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title"><i class="fa fa-tasks"></i> <span>Gerar Nova O.S</span>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">x</span></button>
                                    </h3>
                                </div>
                                <div class="modal-body">
                                    <div class="alert alert-success message"></div>
                                    <div class="alert alert-danger messageError"></div>
                                    <?php echo $__env->make('servicos.add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $__env->stopSection(); ?>
<?php echo $__env->make('main.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>