<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php if(session('msg')): ?>
                <div class="alert alert-success delete-success"><?php echo e(session('msg')); ?></div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="panel panel">
                <div class="panel-heading panel-primary">
                    <h4 class="panel-title">Ultimos serviços adicionados</h4>
                </div>
                <div class="panel-body">
                    <table class="table table-responsive table-hover">
                        <thead>
                        <th>Cliente</th>
                        <th></th>
                        </thead>
                        <tbody>
                        <?php foreach($servicos as $servico): ?>
                            <tr>
                                <td><?php echo e($servico->cliente->nome); ?></td>
                                <td><a class="btn btn-info pull-right"
                                       href="<?php echo e(route('app.modulos.servicos.show', $servico->id)); ?>"><i
                                                class="fa fa-eye"></i> Visualizar Serviço</a></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="panel-footer">
                    <a class="btn btn-success" href="<?php echo e(route('app.modulos.servicos.index')); ?>"><i class="fa fa-list"></i>
                        Ver todas as Ordens de Serviço</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="panel">
                <div class="panel-heading panel-primary">
                    <h4 class="panel-title">Ultimos orçamentos gerados</h4>
                </div>
                <div class="panel-body">
                    <table class="table table-responsive table-hover">
                        <thead>
                        <th>Cliente</th>
                        <th></th>
                        </thead>
                        <tbody>
                        <?php foreach($orcamentos as $orcamento): ?>
                            <tr>
                                <td><?php echo e($orcamento->cliente); ?></td>
                                <td><a class="btn btn-info pull-right" target="_blank"
                                       href="<?php echo e(route('ver', $orcamento->id)); ?>"><i class="fa fa-eye"></i> Visualizar PDF</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="panel-footer">
                    <a class="btn btn-success" href="<?php echo e(route('app.modulos.orcamentos.index')); ?>"><i
                                class="fa fa-list"></i> <span>Ver todos os orçamentos</span></a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>