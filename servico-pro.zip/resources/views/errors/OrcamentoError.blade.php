<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Orçamento não existe</title>
</head>
<body>
    <h1>Algo deu errado</h1>
    <p>O arquivo referente ao orçamento não existe. Para gerar um novo orçamento clique <a href="">aqui</a>.</p>
</body>
</html>