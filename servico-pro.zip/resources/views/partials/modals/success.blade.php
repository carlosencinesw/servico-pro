<div class="modal modal-success fade msg-ok">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>
                    <i class="fa fa-check-circle"></i>
                    <span>Sucesso</span>
                </h3>
            </div>
            <div class="modal-body">
                <div class="message"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"><i class="fa fa-check"></i> <span>OK</span></button>
            </div>
        </div>
    </div>
</div>