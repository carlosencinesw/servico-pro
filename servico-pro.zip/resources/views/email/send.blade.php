<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Feedback do sistema</title>
</head>
<body>
    <p>Esta é uma mensagem do sistema de feedback do sistema OrçaMelhor</p>
    <label>Usuário:</label> <span>{{$user}}</span><br>
    <label>Mensagem:</label> <span>{{$msg}}</span>
</body>
</html>